import express from "express";
import db from "../config/database.js";
import { ObjectId } from "mongodb";

const router = express.Router();

router.get("/", async (req, res) => {
  let limit = Number(req.query.limit) || 5;
  let collection = db.collection("michelin");
  let result = await collection.find().limit(limit).toArray();
  res.json(result).status(200);
});

// router.get("/:id", async (req, res) => {
//   let id = req.params.id;
//   let collection = db.collection("michelin");
//   let query = {};
//   let ressult = await collection.find(query);

//   if (!ressult) {
//     res.status(404).json({ message: "Not Found" });
//   } else {
//     res.json(ressult).status(200);
//   }
// });

// 65130500058
//1. /country/:country
router.get("/country/:country", async (req, res) => {
  let country = req.params.country;
  let collection = db.collection("michelin");
  let query = { country: country };
  let result = await collection.find(query).toArray();
  res.json(result).status(200);
});

// 65130500058
//2. /cuisine/:cuisine
router.get("/cuisine/:cuisine", async (req, res) => {
  let cuisine = req.params.cuisine;
  let collection = db.collection("michelin");
  let query = { cuisine: cuisine };
  let result = await collection.find(query).toArray();
  res.json(result).status(200);
});

// 65130500058
//3. /countByCountry
router.get("/countByCountry", async (req, res) => {
  let collection = db.collection("michelin");
  let query = [
    {
      $group: {
        _id: "$country",
        count: { $sum: 1 },
      },
    },
    {
      $project: {
        _id: 0,
        country: "$_id",
        count: 1,
      },
    },
  ];
  let result = await collection.aggregate(query).toArray();

  res.status(200).json(result);
});

// 65130500058
//4. /noChefField
router.get("/noChefField", async (req, res) => {
  let collection = db.collection("michelin");
  let result = await collection.find({ chef: { $exists: false } }).toArray();
  res.status(200).json(result);
});

// 65130500058
//5. /chineseInLondon
router.get("/chineseInLondon", async (req, res) => {
  let collection = db.collection("michelin");
  let query = [
    {
      $match: {
        cuisine: "Chinese",
        city: "London",
      },
    },
  ];
  let result = await collection.aggregate(query).toArray();

  res.status(200).json(result);
});

// 65130500058
// 6. /creativeAndInnovative
router.get("/creativeAndInnovative", async (req, res) => {
  let collection = db.collection("michelin");
  let query = { cuisine: { $all: ["Creative", "Innovative"] } };
  let result = await collection.find(query).toArray();

  res.status(200).json(result);
});

// 65130500058
// 7. /thaiCuisineNotInThailand
router.get("/thaiCuisineNotInThailand" ,async (req,res)=>{
    let collection = db.collection("michelin")
    let query = [
        {
            $match: {
                cuisine: "Thai",
                city:{$ne:"Thailand"}
            }
        }
    ]
    let result = await collection.aggregate(query).toArray()

    res.status(200).json(result)
})

// 65130500058
//8. /cuisine2/:cuisine[?stars=n]
router.get("/cuisine2/:cuisine", async (req, res) => {
  let cuisine = req.params.cuisine;
  const stars = parseInt(req.query.stars);
  let collection = db.collection("michelin");
  let query = [
    {
      $match: {
        cuisine: cuisine,
      },
    },
  ];
  if (!isNaN(stars)) {
    query.push({
      $match: {
        stars: stars,
      },
    });
  }
  let result = await collection.aggregate(query).toArray();

  res.status(200).json(result);
});

// 65130500058
// 9./top10Cuisines
router.get("/top10Cuisines", async (req, res) => {
  let collection = db.collection("michelin");
  let query = [
    {
      $group: {
        _id: "$cuisine",
        count: { $sum: 1 },
      },
    },
    {
      $sort: { count: -1 },
    },
    {
      $limit: 10,
    },
    {
      $project: {
        _id: 0,
        cuisine: "$_id",
        count: 1,
      },
    },
  ];
  let result = await collection.aggregate(query).toArray();
  res.status(200).json(result);
});

// 65130500058
//10. /thailandWithStreetfoodOrStars3
router.get("/thailandWithStreetfoodOrStars3", async (req, res) => {
  let collection = db.collection("michelin");
  let query = [
    {
      $match: {
        $or: [{ cuisine: "Street Food" }, { stars: { $regex: "^3" } }],
        country: "Thailand",
      },
    },
  ];
  let result = await collection.aggregate(query).toArray();
  res.status(200).json(result);
});

export default router;
